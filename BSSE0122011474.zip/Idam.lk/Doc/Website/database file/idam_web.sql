-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306:3306
-- Generation Time: Apr 11, 2024 at 06:02 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `idam_web`
--

-- --------------------------------------------------------

--
-- Table structure for table `addvertisement`
--

CREATE TABLE `addvertisement` (
  `aid` int(10) NOT NULL,
  `uid` int(10) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `city` varchar(40) DEFAULT NULL,
  `size` decimal(10,0) DEFAULT NULL,
  `bed` int(2) DEFAULT NULL,
  `bath` int(2) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `price` int(15) DEFAULT NULL,
  `tel` varchar(15) DEFAULT NULL,
  `date_time` datetime DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `addvertisement`
--

INSERT INTO `addvertisement` (`aid`, `uid`, `title`, `city`, `size`, `bed`, `bath`, `description`, `price`, `tel`, `date_time`, `status`) VALUES
(18, 10, 'krishan', 'mattegoda', '12', 5, 2, 'fsdsdfssdfs', 20000000, '0728727655', '2024-03-29 20:40:13', 1),
(19, 10, 'house for sale', 'kottawa', '15', 2, 2, 'rdsdfsdfsdfsdfdfdf', 30000000, '0728727655', '2024-03-29 20:41:22', 1),
(21, 10, 'Luxury House for sale', 'kottawa', '10', 5, 3, 'Luxury House for sale', 70000000, '0766945406', '2024-03-30 20:22:43', 1),
(23, 10, 'House sale', 'piliyandala', '20', 5, 3, 'Undefined variable: This error suggests that the variables $min_size and $max_size are not defined before they are being used. This might be because they are not initialized or set in the filters.php file.\r\n\r\nFatal error: The fatal error indicates that the $result variable is a boolean value (false), not a result set from the database query. This could be due to an error in the SQL query itself or some other issue preventing the query from executing successfully', 75000000, '0766945406', '2024-03-31 13:53:26', 0),
(24, 10, 'House sale luxury', 'piliyandala', '20', 5, 3, 'Undefined variable: This error suggests that the variables $min_size and $max_size are not defined before they are being used. This might be because they are not initialized or set in the filters.php file.\r\n\r\nFatal error: The fatal error indicates that the $result variable is a boolean value (false), not a result set from the database query. This could be due to an error in the SQL query itself or some other issue preventing the query from executing successfully', 75000000, '0766945406', '2024-03-31 13:53:53', 0),
(25, 19, 'house for sale', 'mattegoda', '20', 5, 3, 'house for sale matte goda good area', 75000000, '0112485696', '2024-03-31 13:56:28', 0),
(29, 19, 'house for sale piliyandal', 'piliyandala', '20', 5, 3, 'house for sale in piliyandala', 75000000, '0112485696', '2024-03-31 14:01:06', 0);

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `aid` int(10) DEFAULT NULL,
  `img1` varchar(100) DEFAULT NULL,
  `img2` varchar(100) DEFAULT NULL,
  `img3` varchar(100) DEFAULT NULL,
  `img4` varchar(100) DEFAULT NULL,
  `img5` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `aid`, `img1`, `img2`, `img3`, `img4`, `img5`) VALUES
(23, 18, NULL, NULL, NULL, NULL, NULL),
(24, 19, NULL, NULL, NULL, NULL, NULL),
(28, 20, NULL, NULL, NULL, NULL, NULL),
(29, 21, NULL, NULL, NULL, NULL, NULL),
(30, 22, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `uid` int(10) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `nic` varchar(15) DEFAULT NULL,
  `tel` varchar(15) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `pw` varchar(30) DEFAULT NULL,
  `date_time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uid`, `name`, `nic`, `tel`, `email`, `pw`, `date_time`) VALUES
(10, 'Krishan Prageeth Prageeth Kumara', '200010602870', '0728727655', 'vkkpkumara@gmail.com', '1234', '2024-03-23 00:12:52'),
(18, 'Krishan', '200010602870', '0728727655', 'vkkpkumara13034@gmail.com', '7894', '2024-03-23 00:44:41'),
(19, 'Tharindu', '200010602870', '0112485696', 'Krishanprageeth87@gmail.com', '7164', '2024-03-31 13:55:26'),
(20, 'kavidu', '200010602870', '0728727655', 'kavindu13034@gmail.com', '1234', '2024-04-07 20:19:19');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addvertisement`
--
ALTER TABLE `addvertisement`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `aid` (`aid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addvertisement`
--
ALTER TABLE `addvertisement`
  MODIFY `aid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `uid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
