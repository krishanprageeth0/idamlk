<style type="text/css">

        .bg-cl1{background-color:#425F57;}
        .f-cl1{color:#425F57;}
        
        /*Body*/
        body{background-color:#e6e9ed; font-family:Arial;}
        a{text-decoration:none}

        /*Home*/
        .text-1{font-weight:700;  }
        .text-label{font-size:10pt; color:#74777a; margin-bottom:7px;}
        .add-img{height:200px object-fit:cover;}
        .add-text1{font-size:18pt; font-weight:700;color:black;}
        .add-text2{font-size:13pt; }
        .add-text3{font-size:13pt; color:#74777a;}
        .add-text4{font-size:15pt; font-weight:700;}
        .add-div{ background-color:#faf3dc; border:2px solid #faeaac; }
        .add-div:hover{box-shadow:0px 0px 5px 2px #bdfa23; }


        /*addverd*/

        .img1{height:500px; object-fit:cover;}
        .addverd h1{font-size:22pt; font-weight:700;color:black;}
        .addverd h2{font-size:18pt; font-weight:700;color:black;}
        .addverd .price{font-size:18pt; font-weight:700;}
        .addverd .desc{font-size:12pt; color:gray;}
        .addverd .tel{font-size:18pt; color:gray;}
    
        


</style>