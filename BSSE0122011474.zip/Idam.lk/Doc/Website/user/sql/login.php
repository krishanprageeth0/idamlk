<?php
// DB CONN
include '../../library/dbconn.php';

// Data
$email = $_REQUEST["email"];
$pw = $_REQUEST["pw"];

$check = 0;


$sql = "SELECT * FROM user WHERE email='$email' AND pw='$pw'";


$result = $conn->query($sql);


if ($result->num_rows > 0) {
    
    $row = $result->fetch_assoc();
    $check = 1;
    $uid = $row["uid"];
    $name = $row["name"];

   
    session_start();

    
    $_SESSION["uid"] = $uid;
    $_SESSION["uname"] = $name;

   
    header("Location: ../../user_acc/index.php");
    exit();
} else {
    
        echo "<script>";
        echo "alert('Please login again!');";
        echo "window.location.replace('../');";
        echo "</script>";
    exit();
}
?>
