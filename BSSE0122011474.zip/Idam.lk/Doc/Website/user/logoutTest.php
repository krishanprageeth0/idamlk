<?php

require 'logout.php'; // Ensure this path is correct relC:\xampp\htdocs\Idam.lk\Idam.lk\Doc\Website\user\logout.phpative to removedTest.php

use PHPUnit\Framework\TestCase;

class logoutTest extends TestCase
{
    public function testlogoutFunction() {
        // Pass an argument to removedFunction
        $result = logoutFunction('expected_value'); 
        $this->assertEquals('expected output', $result); 

        $result = logoutFunction('unexpected_value'); 
        $this->assertEquals('unexpected output', $result); 
    }
}
?>